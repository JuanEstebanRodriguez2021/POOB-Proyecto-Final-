package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

import domain.IceCream;
import domain.Flavor;
import domain.Position;
import domain.Calamar;
import domain.Cherry;
import domain.Pineapple;
import domain.saveFlavor;

public class LevelTwo extends JPanel {

    private final int TILE = 40;
    private final int ROWS = 15;
    private final int COLS = 20;

    private Image floorImg;
    private Image iceBlockImg;
    private Image playerImg;
    private Image calamarImg;
    private Image pineappleImg;
    private Image cherryImg;

    private IceCream player;
    private Calamar calamar;

    private List<Cherry> cherries;
    private List<Pineapple> pineapples;
    private List<Position> iceBlocks;
    private int lastDirection = KeyEvent.VK_DOWN;
    private boolean modoCrear = false; // false = romper, true = crear

    public LevelTwo(JFrame parent) {
        setPreferredSize(new Dimension(COLS * TILE, ROWS * TILE));
        setFocusable(true);

        loadImages();
        initLevel();

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    if (modoCrear) {
                        createIce();
                    } else {
                        breakIce();
                    }
                    modoCrear = !modoCrear;
                } else {
                    movePlayer(e.getKeyCode());
                }
            }
        });
    }

    private void loadImages() {
        floorImg = new ImageIcon("resources/floor.jpg").getImage();
        iceBlockImg = new ImageIcon("resources/iceBlock.jpg").getImage();
        calamarImg = new ImageIcon("resources/calamar.png").getImage();
        cherryImg = new ImageIcon("resources/cherry.png").getImage();
        pineappleImg = new ImageIcon("resources/pineapple.png").getImage();

        Flavor f = saveFlavor.selectedFlavor;
        if (f == Flavor.CHOCOLATE) {
            playerImg = new ImageIcon("resources/Chocolate.png").getImage();
        } else if (f == Flavor.VANILLA) {
            playerImg = new ImageIcon("resources/Vainilla.png").getImage();
        } else  {
            playerImg = new ImageIcon("resources/Fresa.png").getImage(); //Fresa
        }
    }

    private void initLevel() {
        Flavor f = saveFlavor.selectedFlavor;
        player = new IceCream(f, 1, new Position(9, 11));
        calamar = new Calamar(new Position(15, 11));

        cherries = new ArrayList<>();
        int[][] cherryPositions = {
                { 8, 5 }, { 9, 5 }, { 10, 5 }, { 11, 5 },
                { 8, 6 }, { 11, 6 },
                { 8, 7 }, { 11, 7 },
                { 8, 8 }, { 9, 8 }, { 10, 8 }, { 11, 8 }
        };
        for (int[] p : cherryPositions) {
            cherries.add(new Cherry(p[1], p[0]));
        }

        pineapples = new ArrayList<>();
        int[][] pineapplePositions = {
                { 6, 10 }, { 7, 10 }, { 8, 10 }, { 9, 10 },
                { 6, 11 }, { 9, 11 },
                { 6, 12 }, { 9, 12 },
                { 6, 13 }, { 7, 13 }, { 8, 13 }, { 9, 13 }
        };
        for (int[] p : pineapplePositions) {
            pineapples.add(new Pineapple(p[1], p[0]));
        }

        iceBlocks = new ArrayList<>();
        for (int c = 3; c < COLS - 3; c++) {
            iceBlocks.add(new Position(c, 3));
            iceBlocks.add(new Position(c, 9));
        }
    }

    private void breakIce() {
        int x = player.getPosition().getX();
        int y = player.getPosition().getY();

        int dx = 0;
        int dy = 0;
        if (lastDirection == KeyEvent.VK_UP) {
            dy = -1;
        } else if (lastDirection == KeyEvent.VK_DOWN) {
            dy = 1;
        } else if (lastDirection == KeyEvent.VK_LEFT) {
            dx = -1;
        } else if (lastDirection == KeyEvent.VK_RIGHT) {
            dx = 1;
        }

        int posX = x + dx;
        int posY = y + dy;
        
        while (posX >= 0 && posX < COLS && posY >= 0 && posY < ROWS) {
            boolean encontroHielo = false;
            
            for (int i = 0; i < iceBlocks.size(); i++) {
                Position p = iceBlocks.get(i);
                if (p.getX() == posX && p.getY() == posY) {
                    iceBlocks.remove(i);
                    encontroHielo = true;
                    break;
                }
            }
            
            if (!encontroHielo) {
                break;
            }
            
            posX = posX + dx;
            posY = posY + dy;
        }
        
        repaint();
    }

    private void createIce() {
        int x = player.getPosition().getX();
        int y = player.getPosition().getY();

        int dx = 0;
        int dy = 0;
        if (lastDirection == KeyEvent.VK_UP) {
            dy = -1;
        } else if (lastDirection == KeyEvent.VK_DOWN) {
            dy = 1;
        } else if (lastDirection == KeyEvent.VK_LEFT) {
            dx = -1;
        } else if (lastDirection == KeyEvent.VK_RIGHT) {
            dx = 1;
        }

        int posX = x + dx;
        int posY = y + dy;
        
        while (posX >= 0 && posX < COLS && posY >= 0 && posY < ROWS) {
            boolean hayHielo = false;
            for (int i = 0; i < iceBlocks.size(); i++) {
                Position p = iceBlocks.get(i);
                if (p.getX() == posX && p.getY() == posY) {
                    hayHielo = true;
                    break;
                }
            }
            
            if (hayHielo) {
                break;
            }
            
            iceBlocks.add(new Position(posX, posY));
            
            // Avanzar a la siguiente posicion
            posX = posX + dx;
            posY = posY + dy;
        }
        
        repaint();
    }

    private void movePlayer(int keyCode) {
        int x = player.getPosition().getX();
        int y = player.getPosition().getY();

        if (keyCode == KeyEvent.VK_UP) {
            y = y - 1;
            lastDirection = KeyEvent.VK_UP;
        }
        if (keyCode == KeyEvent.VK_DOWN) {
            y = y + 1;
            lastDirection = KeyEvent.VK_DOWN;
        }
        if (keyCode == KeyEvent.VK_LEFT) {
            x = x - 1;
            lastDirection = KeyEvent.VK_LEFT;
        }
        if (keyCode == KeyEvent.VK_RIGHT) {
            x = x + 1;
            lastDirection = KeyEvent.VK_RIGHT;
        }
        
        if (x < 0 || x >= COLS || y < 0 || y >= ROWS) 
           return;

        Position next = new Position(x, y);
        for (Position p : iceBlocks) {
            if (p.getX() == next.getX() && p.getY() == next.getY()) {
                return;
            }
        }

        player.setPosition(next);

        for (int i = 0; i < cherries.size(); i++) {
            Cherry c = cherries.get(i);
            if (c.getCol() == x && c.getRow() == y) {
                cherries.remove(i);
                break;
            }
        }

        for (int i = 0; i < pineapples.size(); i++) {
            Pineapple p = pineapples.get(i);
            if (p.getCol() == x && p.getRow() == y) {
                pineapples.remove(i);
                break;
            }
        }

        // mensaje de victoria cuando se recogen todas las cerezas Y todas las piñas
        if (cherries.isEmpty() && pineapples.isEmpty()) {
            JOptionPane.showMessageDialog(this, "¡Felicidades! Has recogido todas las frutas.\n¡Pasas al siguiente nivel!");
            SwingUtilities.getWindowAncestor(this).dispose();
            // Se abre el Level 3
            new LevelThree();
            return;
        }

        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                g.drawImage(floorImg, c * TILE, r * TILE, TILE, TILE, this);
            }
        }

        for (Position p : iceBlocks) {
            g.drawImage(iceBlockImg, p.getX() * TILE, p.getY() * TILE, TILE, TILE, this);
        }

        for (Cherry c : cherries) {
            g.drawImage(cherryImg, c.getCol() * TILE, c.getRow() * TILE, TILE, TILE, this);
        }

        for (Pineapple p : pineapples) {
            g.drawImage(pineappleImg, p.getCol() * TILE, p.getRow() * TILE, TILE, TILE, this);
        }

        g.drawImage(calamarImg,
                calamar.getPosition().getX() * TILE,
                calamar.getPosition().getY() * TILE,
                TILE, TILE, this);

        g.drawImage(playerImg,
                player.getPosition().getX() * TILE,
                player.getPosition().getY() * TILE,
                TILE, TILE, this);
    }

    public static void showInFrame() {
        JFrame frame = new JFrame("Level 2");
        
        // No cerrar automaticamente, nosotros controlamos el cierre
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        // listener para cuando se presiona la X
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(
                    frame,
                    "¿Estás seguro que deseas salir del juego?",
                    "Confirmar salida",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
                );
                
                if (respuesta == JOptionPane.YES_OPTION) {
                    frame.dispose();
                    System.exit(0);
                }
            }
        });
        
        LevelTwo panel = new LevelTwo(frame);
        frame.setContentPane(panel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        panel.requestFocusInWindow();
    }
}

package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

/**
 * Selection of the players and CPU
 * Juan Esteban Rodriguez - Sara Gonzalez
 */
public class ModeSelection extends JFrame {

    private JButton btnOnePlayer;
    private JButton btnTwoPlayers;
    private JButton btnBack;
    private JLabel background;

    public static String selectedMode = "Player";

    public ModeSelection() {
        setTitle("Play Menu");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // Agregar listener para confirmar salida
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                confirmarSalida();
            }
        });

        prepareElements();
        prepareActions();

        setVisible(true);
    }

    private void confirmarSalida() {
        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro que deseas salir del juego?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(new Color(139, 69, 19)); // Color marrón para el texto
        button.setBackground(new Color(255, 248, 220)); // Color crema
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(139, 69, 19), 3),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Efecto hover
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(255, 228, 181));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(255, 248, 220));
            }
        });

        return button;
    }

    private void prepareElements() {
        // Fondo
        File file = new File("resources/backgr.png");
        ImageIcon bgIcon = new ImageIcon(file.getAbsolutePath());
        background = new JLabel(bgIcon) {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image img = bgIcon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };
        background.setBounds(0, 0, getWidth(), getHeight());
        background.setLayout(null);

        // Título
        JLabel title = new JLabel("HOW MANY SCOOPS?", SwingConstants.CENTER);
        title.setFont(new Font("Arial Black", Font.BOLD, 28));
        title.setForeground(new Color(139, 69, 19));
        title.setBounds(50, 50, 500, 50);

        // Panel para las imágenes de helado
        JPanel playerPanel = new JPanel();
        playerPanel.setLayout(null);
        playerPanel.setOpaque(false);
        playerPanel.setBounds(50, 140, 500, 180);

        // Imagen 1 Player
        ImageIcon icon1 = new ImageIcon("resources/option1player.jpg");
        JLabel img1Player = new JLabel(icon1);
        img1Player.setBounds(70, 0, 150, 150);

        // Imagen 2 Players
        ImageIcon icon2 = new ImageIcon("resources/option2player.jpg");
        JLabel img2Players = new JLabel(icon2);
        img2Players.setBounds(280, 0, 150, 150);

        playerPanel.add(img1Player);
        playerPanel.add(img2Players);

        // Botones debajo de las imágenes
        btnOnePlayer = createStyledButton("1 PLAYER");
        btnOnePlayer.setBounds(175, 340, 120, 40);

        btnTwoPlayers = createStyledButton("2 PLAYERS");
        btnTwoPlayers.setBounds(305, 340, 120, 40);

        // Botón BACK
        btnBack = createStyledButton("BACK");
        btnBack.setBounds(250, 400, 100, 40);

        background.add(title);
        background.add(playerPanel);
        background.add(btnOnePlayer);
        background.add(btnTwoPlayers);
        background.add(btnBack);

        add(background);
    }

    private void prepareActions() {
        btnOnePlayer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                selectedMode = "Player";
                new CharacterSelection();
                dispose();
            }
        });

        btnTwoPlayers.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                selectedMode = "PvsP";
                JOptionPane.showMessageDialog(null, "2 Players: En construcción");
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new BadDOPOCreamGUI();
                dispose();
            }
        });
    }
}
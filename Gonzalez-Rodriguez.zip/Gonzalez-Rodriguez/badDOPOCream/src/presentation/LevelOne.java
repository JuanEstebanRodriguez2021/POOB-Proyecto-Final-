package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

import domain.IceCream;
import domain.Flavor;
import domain.Position;
import domain.Troll;
import domain.Banana;
import domain.saveFlavor;
import domain.Grape;

/**
 * Level 1: jugador, bananas, uvas y troll.
 */
public class LevelOne extends JPanel {

    private final int TILE = 40;
    private final int ROWS = 15;
    private final int COLS = 20;

    private Image floorImg;
    private Image iceBlockImg;
    private Image iglooImg;
    private Image playerImg;
    private Image trollImg;
    private Image bananaImg;
    private Image grapeImg;

    private IceCream player;
    private Troll troll;
    private List<Banana> bananas;
    private List<Grape> grapes;
    private List<Position> igloo;
    private List<Position> iceBlocks;
    private Timer enemyTimer;
    private int lastDirection = KeyEvent.VK_DOWN;
    private boolean grapesCreated = false;
    private boolean modoCrear = false; // false = romper, true = crear

    public LevelOne(JFrame parent) {
        setPreferredSize(new Dimension(COLS * TILE, ROWS * TILE));
        setFocusable(true);

        loadImages();
        initLevel();

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    if (modoCrear) {
                        createIce();
                    } else {
                        breakIce();
                    }
                    // Alternar el modo para la proxima vez
                    modoCrear = !modoCrear;
                } else {
                    movePlayer(e.getKeyCode());
                }
            }
        });

        // Timer para mover el troll cada 200 milisegundos
        enemyTimer = new Timer(200, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                moverTroll();
                repaint();
            }
        });
        enemyTimer.start();
    }

    private void loadImages() {
        floorImg = new ImageIcon("resources/floor.jpg").getImage();
        iceBlockImg = new ImageIcon("resources/iceBlock.jpg").getImage();
        iglooImg = new ImageIcon("resources/igloo.jpg").getImage();
        trollImg = new ImageIcon("resources/troll.jpg").getImage();
        bananaImg = new ImageIcon("resources/platano.png").getImage();
        grapeImg = new ImageIcon("resources/uva.png").getImage();

        Flavor f = saveFlavor.selectedFlavor;
        if (f == Flavor.CHOCOLATE) {
            playerImg = new ImageIcon("resources/Chocolate.png").getImage();
        } else if (f == Flavor.VANILLA) {
            playerImg = new ImageIcon("resources/Vainilla.png").getImage();
        } else {
            playerImg = new ImageIcon("resources/Fresa.png").getImage();
        }
    }

    private void initLevel() {
        Flavor f = saveFlavor.selectedFlavor;

        // jugador centrado abajo, dentro del rectángulo
        player = new IceCream(f, 1, new Position(9, 10));

        troll = new Troll(new Position(3, 10));

        // BANANAS: 3 en cada esquina exterior + 3 en cada esquina del corchete
        bananas = new ArrayList<>();
        int[][] bananaPositions = {
                // esquinas rectángulo exterior (tres por esquina)
                { 2, 2 }, { 3, 2 }, { 2, 3 },
                { 15, 2 }, { 16, 2 }, { 16, 3 },
                { 2, 9 }, { 2, 10 }, { 3, 10 },
                { 15, 10 }, { 16, 9 }, { 16, 10 },

                // esquinas corchete izquierdo
                { 5, 4 }, { 6, 4 },
                { 6, 7 }, { 5, 7 },

                // esquinas corchete derecho
                { 12, 5 }, { 12, 4 },
                { 12, 7 }, { 12, 6 },
        };
        for (int[] p : bananaPositions) {
            bananas.add(new Banana(p[1], p[0]));
        }

        // uvas: se crean al acabar bananas
        grapes = new ArrayList<>();

        // BLOQUES DE HIELO: rectángulo exterior completo
        iceBlocks = new ArrayList<>();

        for (int c = 1; c <= 17; c++) {
            iceBlocks.add(new Position(c, 1)); // arriba
            iceBlocks.add(new Position(c, 11)); // abajo
        }
        for (int r = 2; r <= 10; r++) {
            iceBlocks.add(new Position(1, r)); // izquierda
            iceBlocks.add(new Position(17, r)); // derecha
        }

        // corchete izquierdo alrededor del iglú
        for (int r = 3; r <= 8; r++) {
            iceBlocks.add(new Position(4, r));
        }
        for (int c = 4; c <= 7; c++) {
            iceBlocks.add(new Position(c, 3));
            iceBlocks.add(new Position(c, 8));
        }

        // corchete derecho
        for (int r = 3; r <= 8; r++) {
            iceBlocks.add(new Position(13, r));
        }
        for (int c = 10; c <= 13; c++) {
            iceBlocks.add(new Position(c, 3));
            iceBlocks.add(new Position(c, 8));
        }

        // celdas del iglú para colisiones
        igloo = new ArrayList<>();
        for (int r = 4; r <= 7; r++) {
            for (int c = 7; c <= 11; c++) {
                igloo.add(new Position(c, r));
            }
        }
    }

    private void breakIce() {
        int x = player.getPosition().getX();
        int y = player.getPosition().getY();

        // Calcular direccion segun la ultima tecla presionada
        int dx = 0;
        int dy = 0;
        if (lastDirection == KeyEvent.VK_UP) {
            dy = -1;
        } else if (lastDirection == KeyEvent.VK_DOWN) {
            dy = 1;
        } else if (lastDirection == KeyEvent.VK_LEFT) {
            dx = -1;
        } else if (lastDirection == KeyEvent.VK_RIGHT) {
            dx = 1;
        }

        // Romper hielos en efecto domino
        int posX = x + dx;
        int posY = y + dy;

        while (posX >= 0 && posX < COLS && posY >= 0 && posY < ROWS) {
            boolean encontroHielo = false;

            // Buscar si hay hielo en esta posicion
            for (int i = 0; i < iceBlocks.size(); i++) {
                Position p = iceBlocks.get(i);
                if (p.getX() == posX && p.getY() == posY) {
                    iceBlocks.remove(i);
                    encontroHielo = true;
                    break;
                }
            }

            // Si no hay hielo, parar el efecto domino
            if (!encontroHielo) {
                break;
            }

            // Avanzar a la siguiente posicion
            posX = posX + dx;
            posY = posY + dy;
        }

        repaint();
    }

    private void createIce() {
        int x = player.getPosition().getX();
        int y = player.getPosition().getY();

        // Calcular direccion segun la ultima tecla presionada
        int dx = 0;
        int dy = 0;
        if (lastDirection == KeyEvent.VK_UP) {
            dy = -1;
        } else if (lastDirection == KeyEvent.VK_DOWN) {
            dy = 1;
        } else if (lastDirection == KeyEvent.VK_LEFT) {
            dx = -1;
        } else if (lastDirection == KeyEvent.VK_RIGHT) {
            dx = 1;
        }

        // Crear hielos en efecto domino
        int posX = x + dx;
        int posY = y + dy;

        while (posX >= 0 && posX < COLS && posY >= 0 && posY < ROWS) {
            // Verificar si ya hay hielo en esta posicion
            boolean hayHielo = false;
            for (int i = 0; i < iceBlocks.size(); i++) {
                Position p = iceBlocks.get(i);
                if (p.getX() == posX && p.getY() == posY) {
                    hayHielo = true;
                    break;
                }
            }

            // Verificar si es iglu
            boolean esIglu = false;
            for (int i = 0; i < igloo.size(); i++) {
                Position q = igloo.get(i);
                if (q.getX() == posX && q.getY() == posY) {
                    esIglu = true;
                    break;
                }
            }

            // Si hay obstaculo, parar
            if (hayHielo || esIglu) {
                break;
            }

            // Crear hielo en esta posicion
            iceBlocks.add(new Position(posX, posY));

            // Avanzar a la siguiente posicion
            posX = posX + dx;
            posY = posY + dy;
        }

        repaint();
    }

    private void movePlayer(int keyCode) {
        int x = player.getPosition().getX();
        int y = player.getPosition().getY();

        if (keyCode == KeyEvent.VK_UP) {
            y--;
            lastDirection = KeyEvent.VK_UP;
        }
        if (keyCode == KeyEvent.VK_DOWN) {
            y++;
            lastDirection = KeyEvent.VK_DOWN;
        }
        if (keyCode == KeyEvent.VK_LEFT) {
            x--;
            lastDirection = KeyEvent.VK_LEFT;
        }
        if (keyCode == KeyEvent.VK_RIGHT) {
            x++;
            lastDirection = KeyEvent.VK_RIGHT;
        }

        if (x < 0 || x >= COLS || y < 0 || y >= ROWS)
            return;

        Position next = new Position(x, y);

        for (Position p : iceBlocks) {
            if (p.getX() == next.getX() && p.getY() == next.getY()) {
                return;
            }
        }
        for (Position q : igloo) {
            if (q.getX() == next.getX() && q.getY() == next.getY()) {
                return;
            }
        }

        player.setPosition(next);

        // bananas
        for (int i = 0; i < bananas.size(); i++) {
            Banana b = bananas.get(i);
            if (b.getCol() == x && b.getRow() == y) {
                bananas.remove(i);
                break;
            }
        }

        // uvas
        for (int i = 0; i < grapes.size(); i++) {
            Grape g = grapes.get(i);
            if (g.getCol() == x && g.getRow() == y) {
                grapes.remove(i);
                break;
            }
        }

        // crear uvas cuando no quedan bananas (solo una vez)
        if (bananas.isEmpty() && !grapesCreated) {
            grapesCreated = true;
            int[][] grapePositions = {
                    { 2, 2 }, { 3, 2 }, { 2, 3 },
                    { 15, 2 }, { 16, 2 }, { 16, 3 },
                    { 2, 9 }, { 2, 10 }, { 3, 10 },
                    { 15, 10 }, { 16, 9 }, { 16, 10 },

            };
            for (int[] p : grapePositions) {
                grapes.add(new Grape(p[1], p[0]));
            }
        }

        // colisión con troll
        if (player.getPosition().getX() == troll.getPosition().getX()
                && player.getPosition().getY() == troll.getPosition().getY()) {
            enemyTimer.stop();
            JOptionPane.showMessageDialog(this, "¡Te atrapó el troll!");
            SwingUtilities.getWindowAncestor(this).dispose();
            return;
        }

        // victoria - cuando se recogen todas las bananas Y todas las uvas
        if (bananas.isEmpty() && grapesCreated && grapes.isEmpty()) {
            enemyTimer.stop();
            JOptionPane.showMessageDialog(this,
                    "¡Felicidades! Has recogido todas las frutas.\n¡Pasas al siguiente nivel!");
            SwingUtilities.getWindowAncestor(this).dispose();
            // Abrir Level 2
            LevelTwo.showInFrame();
            return;
        }

        repaint();
    }

    // troll recorre la fila de abajo dentro del rectángulo, de izquierda a derecha
    // y vuelta
    private void moverTroll() {
        int x = troll.getPosition().getX();
        int y = troll.getPosition().getY();

        // límite interno: entre columnas 2 y 16 en la fila 10
        if (x < 16 && y == 10 && player != null) {
            x++; // va hacia la derecha
        } else if (x == 16 && y > 2) {
            y--; // sube por la derecha
        } else if (y == 2 && x > 2) {
            x--; // va a la izquierda por arriba
        } else if (x == 2 && y < 10) {
            y++; // baja por la izquierda
        }

        troll.setPosition(new Position(x, y));

        // Verificar si el troll atrapo al jugador
        int playerX = player.getPosition().getX();
        int playerY = player.getPosition().getY();

        if (x == playerX && y == playerY) {
            enemyTimer.stop();
            JOptionPane.showMessageDialog(this, "¡Te atrapó el troll! Perdiste.");
            SwingUtilities.getWindowAncestor(this).dispose();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                g.drawImage(floorImg, c * TILE, r * TILE, TILE, TILE, this);
            }
        }

        for (Position p : iceBlocks) {
            g.drawImage(iceBlockImg, p.getX() * TILE, p.getY() * TILE, TILE, TILE, this);
        }

        g.drawImage(iglooImg, 8 * TILE, 4 * TILE, TILE * 4, TILE * 4, this);

        for (Banana b : bananas) {
            g.drawImage(bananaImg, b.getCol() * TILE, b.getRow() * TILE, TILE, TILE, this);
        }
        for (Grape gr : grapes) {
            g.drawImage(grapeImg, gr.getCol() * TILE, gr.getRow() * TILE, TILE, TILE, this);
        }

        g.drawImage(trollImg,
                troll.getPosition().getX() * TILE,
                troll.getPosition().getY() * TILE,
                TILE, TILE, this);

        g.drawImage(playerImg,
                player.getPosition().getX() * TILE,
                player.getPosition().getY() * TILE,
                TILE, TILE, this);
    }

    public static void showInFrame() {
        JFrame frame = new JFrame("Level 1");

        // No cerrar automaticamente, nosotros controlamos el cierre
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // Agregar listener para cuando se presiona la X
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                // Mostrar mensaje de confirmacion
                int respuesta = JOptionPane.showConfirmDialog(
                        frame,
                        "¿Estás seguro que deseas salir del juego?",
                        "Confirmar salida",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE);

                // Si el usuario dice que si, cerrar el juego
                if (respuesta == JOptionPane.YES_OPTION) {
                    frame.dispose();
                    System.exit(0);
                }
            }
        });

        LevelOne panel = new LevelOne(frame);
        frame.setContentPane(panel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        panel.requestFocusInWindow();
    }

    public static void main(String[] args) {
        System.out.println("Creando el Nivel uno...");
        showInFrame();
    }
}

package presentation;

import domain.saveFlavor;
import domain.Flavor;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class CharacterSelection extends JFrame {

    private JButton btnChocolate;
    private JButton btnVainilla;
    private JButton btnFresa;
    private JButton btnBack;
    private JLabel background;

    public CharacterSelection() {
        setTitle("Seleccion sabor");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        // Agregar listener para confirmar salida
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                confirmarSalida();
            }
        });

        prepareElements();
        prepareActions();

        setVisible(true);
    }
    
    private void confirmarSalida() {
        int respuesta = JOptionPane.showConfirmDialog(
            this,
            "\u00bfEst\u00e1s seguro que deseas salir del juego?",
            "Confirmar salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (respuesta == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }

    private void prepareElements() {

        // Fondo con la imagen grande
        ImageIcon bgIcon = new ImageIcon("resources/chooseFlavor.png");
        background = new JLabel(bgIcon);
        background.setLayout(null); // para usar setBounds
        setContentPane(background);

        // Botón BACK arriba a la izquierda
        btnBack = new JButton("BACK");
        btnBack.setBounds(20, 20, 80, 30);

        // Botones de texto para los sabores, debajo de la imagen
        btnChocolate = new JButton("CHOCOLATE");
        btnChocolate.setBounds(80, 420, 120, 40);

        btnVainilla = new JButton("VAINILLA");
        btnVainilla.setBounds(240, 420, 120, 40);

        btnFresa = new JButton("FRESA");
        btnFresa.setBounds(400, 420, 120, 40);

        // Opcional: estilo básico
        Font font = new Font("Arial", Font.BOLD, 14);
        btnChocolate.setFont(font);
        btnVainilla.setFont(font);
        btnFresa.setFont(font);
        btnBack.setFont(font);

        background.add(btnBack);
        background.add(btnChocolate);
        background.add(btnVainilla);
        background.add(btnFresa);
    }

    private void prepareActions() {

        btnChocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveFlavor.selectedFlavor = Flavor.CHOCOLATE;
                new LevelSelection();
                dispose();
            }
        });

        btnFresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveFlavor.selectedFlavor = Flavor.STRAWBERRY;
                new LevelSelection();
                dispose();
            }
        });

        btnVainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveFlavor.selectedFlavor = Flavor.VANILLA;
                new LevelSelection();
                dispose();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ModeSelection();
                dispose();
            }
        });
    }
}

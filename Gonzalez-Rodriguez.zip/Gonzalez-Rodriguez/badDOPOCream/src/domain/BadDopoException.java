package domain;

public class BadDopoException extends RuntimeException {

    public enum Type {
        FLAVOR_NOT_SELECTED,
        IMAGES_NOT_LOADED,
        TROLL_NOT_INITIALIZED,
        PLAYER_NOT_INITIALIZED
    }

    private final Type type;

    public BadDopoException(Type type) {
        super(messageFor(type));
        this.type = type;
    }

    public BadDopoException(Type type, Throwable cause) {
        super(messageFor(type), cause);
        this.type = type;
    }

    public Type getType() {
        return type;
    }

    private static String messageFor(Type type) {
        switch (type) {
            case FLAVOR_NOT_SELECTED:
                return "No se seleccionó sabor antes de entrar al nivel.";
            case IMAGES_NOT_LOADED:
                return "No se pudieron cargar las imágenes del nivel.";
            case TROLL_NOT_INITIALIZED:
                return "El troll no fue inicializado correctamente.";
            case PLAYER_NOT_INITIALIZED:
                return "El jugador no fue inicializado correctamente.";
            default:
                return "Error de nivel desconocido.";
        }
    }
}

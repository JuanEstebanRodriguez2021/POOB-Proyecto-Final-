package domain;

/**
 * Especifica atributos y metodos que usa el jugador (ice cream)
 * Sara Gonzalez
 */
public class IceCream {

    private Flavor flavor;
    private int lives;
    private Position position;

    public IceCream(Flavor flavor, int lives, Position position) {
        this.flavor = flavor;
        this.lives = lives;
        this.position = position;
    }

    public Flavor getFlavor() {
        return flavor;
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }
}

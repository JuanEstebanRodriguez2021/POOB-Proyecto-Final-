package domain;

/**
 * Enemigo tipo Maceta: persigue al jugador
 * acercándose una celda por actualización.
 * No rompe bloques.
 */
public class Maceta extends Enemy {

    public Maceta(Position position) {
        super(position);
    }

    @Override
    public void move(Map map, Position iceCreamPos) {
        int x = position.getX();
        int y = position.getY();
        int iceX = iceCreamPos.getX();
        int iceY = iceCreamPos.getY();

        // Se acerca primero en X, luego en Y
        if (iceX > x) {
            x++;
        } else if (iceX < x) {
            x--;
        } else if (iceY > y) {
            y++;
        } else if (iceY < y) {
            y--;
        }

        Position newPos = new Position(x, y);
        if (!map.isBlocked(newPos)) {
            position.setX(x);
            position.setY(y);
        }
    }
}

package domain;

import javax.swing.Timer;
import java.awt.event.ActionListener;

/**
 * Clase Fogata - Obstáculo mortal que puede apagarse temporalmente
 * Los helados mueren al tocarla
 * Los enemigos no sufren daño
 * Se apaga al crear hielo sobre ella y se vuelve a encender después de 10
 * segundos
 */
public class Fogata {
    private Position position;
    private boolean encendida;
    private Timer timerReencendido;

    public Fogata(int col, int row) {
        this.position = new Position(col, row);
        this.encendida = true;
    }

    public Fogata(Position position) {
        this.position = position;
        this.encendida = true;
    }

    public Position getPosition() {
        return position;
    }

    public int getCol() {
        return position.getX();
    }

    public int getRow() {
        return position.getY();
    }

    public boolean isEncendida() {
        return encendida;
    }

    /**
     * Apaga la fogata temporalmente
     * Se volverá a encender después de 10 segundos (10000 ms)
     */
    public void apagar() {
        if (!encendida) {
            return; // Ya está apagada
        }

        encendida = false;

        // Detener timer anterior si existe
        if (timerReencendido != null && timerReencendido.isRunning()) {
            timerReencendido.stop();
        }

        // Crear nuevo timer para reencender después de 10 segundos
        timerReencendido = new Timer(10000, new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                reencender();
            }
        });
        timerReencendido.setRepeats(false); // Solo una vez
        timerReencendido.start();
    }

    /**
     * Reenciende la fogata
     */
    private void reencender() {
        encendida = true;
        if (timerReencendido != null) {
            timerReencendido.stop();
        }
    }

    /**
     * Verifica si el jugador toca esta fogata
     * 
     * @param playerPos Posición del jugador
     * @return true si el jugador está en la misma posición y la fogata está
     *         encendida
     */
    public boolean matarJugador(Position playerPos) {
        return encendida &&
                position.getX() == playerPos.getX() &&
                position.getY() == playerPos.getY();
    }

    /**
     * Detiene todos los timers (útil al cerrar el nivel)
     */
    public void detenerTimers() {
        if (timerReencendido != null && timerReencendido.isRunning()) {
            timerReencendido.stop();
        }
    }
}
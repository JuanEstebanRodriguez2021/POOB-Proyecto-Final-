package presentation;

import javax.swing.*;
import java.awt.*;

public class LevelOne extends JPanel {

    private final int block = 40;
    private final int rows = 14;
    private final int cols = 18;
    private JFrame parentFrame;

    private Image tileWhite;
    private Image iceBlock;
    private Image igloo;

    public LevelOne(JFrame frame) {
        this.parentFrame = frame;
        setPreferredSize(new Dimension(cols * block, rows * block));
        setLayout(null);

        tileWhite = new ImageIcon("resources/tile_white.jpg").getImage();
        iceBlock = new ImageIcon("resources/ice_block.jpg").getImage();
        igloo = new ImageIcon("resources/igloo.jpg").getImage();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                g.drawImage(tileWhite, x * block, y * block, block, block, this);
            }
        }

        g.drawImage(igloo, 7 * block, 4 * block, block * 4, block * 4, this);
    }
}





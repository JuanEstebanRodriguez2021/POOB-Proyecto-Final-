package presentation;

import javax.swing.*;
import java.awt.*;

public class LevelSelection extends JPanel {

    private JButton level1;
    private JButton level2;
    private JButton level3;
    private JButton backButton;
    private JLabel title;

    private JFrame parentFrame;

    public LevelSelection(JFrame frame) {
        this.parentFrame = frame;
        prepareElements();
        prepareActions();
    }

    private JButton createImageButton(String path) {
        ImageIcon icon = new ImageIcon(path);
        JButton button = new JButton(icon);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JPanel centeredRow(int hGap) {
        FlowLayout layout = new FlowLayout(FlowLayout.CENTER, hGap, 10);
        JPanel panel = new JPanel(layout);
        panel.setOpaque(false);
        return panel;
    }

    private void prepareElements() {
        setLayout(new BorderLayout());
        title = new JLabel("Seleccione el nivel que desea jugar", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setForeground(Color.BLACK);
        add(title, BorderLayout.NORTH);

        JPanel main = new JPanel(new GridLayout(2, 1, 20, 20));
        main.setOpaque(false);

        JPanel levels = centeredRow(40);
        level1 = createImageButton("resources/level1.png");
        level2 = createImageButton("resources/level2.png");
        level3 = createImageButton("resources/level3.png");
        levels.add(level1);
        levels.add(level2);
        levels.add(level3);

        JPanel back = centeredRow(80);
        backButton = createImageButton("resources/back.jpg");
        back.add(backButton);

        main.add(levels);
        main.add(back);

        add(main, BorderLayout.CENTER);
    }

    private void prepareActions() {

        backButton.addActionListener(e -> {
            parentFrame.setContentPane(new CharacterSelection(parentFrame));
            parentFrame.revalidate();
            parentFrame.repaint();
        });

        level1.addActionListener(e -> {
            parentFrame.setContentPane(new LevelOne(parentFrame));
            parentFrame.revalidate();
            parentFrame.repaint();
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image back = new ImageIcon("resources/board.jpeg").getImage();
        g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
    }
}

package presentation;

import javax.swing.*;
import java.awt.*;

public class CharacterSelection extends JPanel {

    private JButton flavor1;
    private JButton flavor2;
    private JButton monster1;
    private JButton monster2;
    private JButton playButton;
    private JButton backButton;
    private JLabel title;

    private JFrame parentFrame;

    public CharacterSelection(JFrame frame) {
        this.parentFrame = frame;
        prepareElements();
        prepareActions();
    }

    private JButton createImageButton(String path) {
        ImageIcon icon = new ImageIcon(path);
        JButton button = new JButton(icon);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JPanel centeredRow(int hGap) {
        FlowLayout layout = new FlowLayout(FlowLayout.CENTER, hGap, 10);
        JPanel panel = new JPanel(layout);
        panel.setOpaque(false);
        return panel;
    }

    private void prepareElements() {
        setLayout(new BorderLayout());
        title = new JLabel("Seleeccione su personaje", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setForeground(Color.BLACK);
        add(title, BorderLayout.NORTH);

        JPanel main = new JPanel(new GridLayout(2, 1, 20, 20));
        main.setOpaque(false);
        

        JPanel flavors = centeredRow(40);
        flavor1 = createImageButton("resources/flavor1.jpg");
        flavor2 = createImageButton("resources/flavor2.jpg");
        flavors.add(flavor1);                        
        flavors.add(flavor2);

        JPanel monsters = centeredRow(40);
        monster1 = createImageButton("resources/monster1.jpg");
        monster2 = createImageButton("resources/monster2.jpg");
        monsters.add(monster1);
        monsters.add(monster2);

        JPanel bottom = centeredRow(80);
        playButton = createImageButton("resources/play.jpg");
        backButton = createImageButton("resources/back.jpg");
        bottom.add(backButton);
        bottom.add(playButton);

        main.add(flavors);
        main.add(monsters);
        main.add(bottom);

        add(main, BorderLayout.CENTER);
    }

    private void prepareActions() {
        backButton.addActionListener(e -> {
            parentFrame.setContentPane(new ModeSelection(parentFrame));
            parentFrame.revalidate();
            parentFrame.repaint();
        });

        playButton.addActionListener(e -> {
            parentFrame.setContentPane(new LevelSelection(parentFrame));
            parentFrame.revalidate();
            parentFrame.repaint();
        });       
        
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image back = new ImageIcon("resources/board.jpeg").getImage();
        g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
    }
}
x
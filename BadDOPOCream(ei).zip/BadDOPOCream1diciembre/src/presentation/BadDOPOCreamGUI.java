package presentation;

import javax.swing.*;
import java.awt.*;

public class BadDOPOCreamGUI extends JPanel {

    private JButton playButton;
    private JButton exitButton;
    private JFrame parentFrame;

    public BadDOPOCreamGUI(JFrame frame) {
        this.parentFrame = frame;
        prepareElements();
        prepareActions();
    }

    private void prepareElements() {
        setLayout(new BorderLayout());

        playButton = new JButton("Play");
        exitButton = new JButton("Exit");

        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.add(playButton);
        bottomPanel.add(exitButton);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void prepareActions() {
        playButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                parentFrame.setContentPane(new ModeSelection(parentFrame));
                parentFrame.revalidate();
            }
        });

        exitButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                System.exit(0);
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        try {
            Image back = new ImageIcon(getClass().getResource("/resources/inicio.jpg")).getImage();
            g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
        } catch (Exception e) {
            g.setColor(new Color(100, 150, 200));
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Bad DOPO Cream");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                frame.setContentPane(new BadDOPOCreamGUI(frame));

                frame.setSize(800, 600);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }
}

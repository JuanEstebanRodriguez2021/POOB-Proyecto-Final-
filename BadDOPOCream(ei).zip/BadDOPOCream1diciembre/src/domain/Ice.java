package domain;
/**
 * Hielo de badDopoCream
 * 
 * Sara Gonzalez
 */
public class Ice {
    private boolean breakable;
    private Position position;

    /**
     * Constructor for objects of class ice
     */
    public Ice(boolean breakable, Position position) {
        this.breakable = breakable;
        this.position = position;
        
    }

    public void breakIce () {
        if (breakable) {
            breakable = false;
            System.out.println("Hielo roto en (" + position.getX() + ", " + position.getY() + ")");
        }
    }
    
    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public boolean isBreakable() {
        return breakable;
    }

    public void setBreakable(boolean breakable) {
        this.breakable = breakable;
    }
}
package domain;

/**
 * clase Fruit
 * 
 * Sara g 
 * @version (a version number or a date)
 */

public class Fruit {

    private Position position;
    private boolean collected;
    private FruitType type;

    public Fruit(Position position, FruitType type) {
        this.position = position;
        this.type = type;
        this.collected = false;
    }

    /**
     * Marca la fruta como recolectada.
     */
    public void collect() {
        this.collected = true;
    }
}

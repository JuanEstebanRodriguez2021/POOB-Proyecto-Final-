package domain;

/**
 * Especifica los tipos de frutas
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class FruitType {

    private int attribute2;

    public FruitType(int attribute2) {
        this.attribute2 = attribute2;
    }
}

package domain;

/**
 * Clase Map
 * Representa el mapa del nivel..
 * 
 * Sara Gonzalez
 */
public class Map {

    private int[][] grid;
    private int height;
    private int width;

    public Map(int width, int height) {
        this.width = width;
        this.height = height;

        this.grid = new int[height][width];
    }

    /**
     * Determina si una posición está bloqueada (valor == 1)
     */
    public boolean isBlocked(Position position) {
        int x = position.getX();
        int y = position.getY();

        // Verifica límites y celdas
        if (x < 0 || x >= width || y < 0 || y >= height) {
            return true; 
        }
        return grid[y][x] == 1;
    }

    public void placeIce(Ice block) {
        Position p = block.getPosition();
        int x = p.getX();
        int y = p.getY();

        if (x >= 0 && x < width && y >= 0 && y < height) {
            grid[y][x] = 2;
        }
    }

    /**
     * Quita un bloque de hielo del mapa.
     */
    public void removeIce(Ice block) {
        Position p = block.getPosition();
        int x = p.getX();
        int y = p.getY();

        if (x >= 0 && x < width && y >= 0 && y < height) {
            grid[y][x] = 0;
        }
    }


}

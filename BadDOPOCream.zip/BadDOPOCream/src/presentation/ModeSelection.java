package presentation;

import javax.swing.*;
import java.awt.*;

public class ModeSelection extends JPanel {

    private JButton cpuVsCpu;
    private JButton playerVsCpu;
    private JButton playerVsPlayer;
    private JButton backButton;
    private JLabel title;

    private JFrame parentFrame;

    public ModeSelection(JFrame frame) {
        this.parentFrame = frame;
        prepareElements();
        prepareActions();
    }

    private JButton createImageButton(String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath);

        JButton button = new JButton(icon);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return button;
    }

    private void prepareElements() {
        setLayout(new GridLayout(4,1,25,20));
        title = new JLabel("¿Cuántos jugadores?", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setForeground(Color.BLACK);

        add(title, BorderLayout.NORTH);

        cpuVsCpu = createImageButton("resources/cpu.jpg");
        playerVsCpu = createImageButton("resources/player.jpg");
        playerVsPlayer = createImageButton("resources/player2.jpg");
        backButton = createImageButton("resources/back.jpg");

        add(cpuVsCpu);
        add(playerVsCpu);
        add(playerVsPlayer);
        add(backButton);
    }

    private void prepareActions() {

        cpuVsCpu.addActionListener(e -> goToCharacterSelect());
        playerVsCpu.addActionListener(e -> goToCharacterSelect());
        playerVsPlayer.addActionListener(e -> goToCharacterSelect());

        backButton.addActionListener(e -> {
            parentFrame.setContentPane(new BadDOPOCreamGUI(parentFrame));
            parentFrame.revalidate();
            parentFrame.repaint();
        });
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image back = new ImageIcon("resources/board.jpeg").getImage();
        g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
    }

    private void goToCharacterSelect() {
        parentFrame.setContentPane(new CharacterSelection(parentFrame));
        parentFrame.revalidate();
        parentFrame.repaint();
    }
}



package presentation;

import javax.swing.*;
import java.awt.*;

public class BadDOPOCreamGUI extends JPanel {

    private JButton playButton;
    private JButton exitButton;
    private JFrame parentFrame;

    public BadDOPOCreamGUI(JFrame frame) {
        this.parentFrame = frame;
        prepareElements();
        prepareActions();
    }

    private void prepareElements() {
        setLayout(new BorderLayout());

        playButton = new JButton("Play");
        exitButton = new JButton("Exit");

        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.add(playButton);
        bottomPanel.add(exitButton);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void prepareActions() {
        playButton.addActionListener(e -> {
            parentFrame.setContentPane(new ModeSelection(parentFrame));
            parentFrame.revalidate();
        });

        exitButton.addActionListener(e -> System.exit(0));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image back = new ImageIcon("resources/inicio.jpg").getImage();
        g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
    }
    public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        JFrame frame = new JFrame("Bad DOPO Cream");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setContentPane(new BadDOPOCreamGUI(frame));

        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
     
     });
   }
}



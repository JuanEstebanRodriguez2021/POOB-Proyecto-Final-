package presentation;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class BadDOPOCreamGUI extends JFrame {

    private JButton playButton;
    private JLabel background;

    public BadDOPOCreamGUI() {
        setTitle("Bad DOPO Cream");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        prepareElements();
        prepareActions();

        setVisible(true);
    }

    private void prepareElements() {
        File file = new File("resources/inicio.jpg");
        ImageIcon backgroundIcon = new ImageIcon(file.getAbsolutePath());

        background = new JLabel(backgroundIcon){
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image img = backgroundIcon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        
        };
        background.setBounds(0, 0, getWidth(), getHeight());
        add(background);

        playButton = new JButton("Play");
        playButton.setBounds(250, 380, 100, 40);
        add(playButton);
    }

    private void prepareActions() {
        playButton.addActionListener(e -> {
            new ModeSelection();
            dispose();
        });
    }

    public static void main(String[] args) {
        new BadDOPOCreamGUI();
    }
}

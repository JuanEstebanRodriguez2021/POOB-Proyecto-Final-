package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * Selection of the levels (1 to 3)
 * Juan Esteban Rodriguez- Sara Gonzalez
 */
public class LevelSelection extends JFrame {

    private JButton btnLevel1;
    private JButton btnLevel2;
    private JButton btnLevel3;
    private JButton btnBack;
    private JLabel title;
    private JLabel background;

    /**
     * Constructor
     */
    public LevelSelection() {

        setTitle("Seleccione el Nivel");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        prepareElements();
        prepareActions();

        setVisible(true);
    }

    private JButton createImageButton(String path, int x, int y, int width, int height) {
        ImageIcon icon = new ImageIcon(path);
        JButton button = new JButton(icon);
        button.setBounds(x, y, width, height);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    /**
     * Method for prepare all elements necessary to the mode selection
     */
    private void prepareElements() {

        ImageIcon titleIcon = new ImageIcon("resources/levelselect.jpg");
        title = new JLabel(titleIcon);
        title.setBounds(150, 40, 300, 80);

        File file = new File("resources/backgr.png");
        ImageIcon bgIcon = new ImageIcon(file.getAbsolutePath());
        background = new JLabel(bgIcon) {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image img = bgIcon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };
        background.setBounds(0, 0, getWidth(), getHeight());
        add(background);

        btnLevel1 = createImageButton("resources/level1.png", 80, 150, 130, 150);
        btnLevel2 = createImageButton("resources/level2.png", 235, 150, 130, 150);
        btnLevel3 = createImageButton("resources/level3.png", 390, 150, 130, 150);

        btnBack = createImageButton("resources/back.jpg", 200, 350, 200, 60);

        add(title);
        add(btnLevel1);
        add(btnLevel2);
        add(btnLevel3);
        add(btnBack);
        add(background);
    }

    private void prepareActions() {

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CharacterSelection();
                dispose();
            }
        });

        btnLevel1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                LevelOne.showInFrame();
                dispose();
            }
        });

        btnLevel2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LevelTwo();
                dispose();
            }
        });

        btnLevel3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LevelThree();
                dispose();
            }
        });
    }

}

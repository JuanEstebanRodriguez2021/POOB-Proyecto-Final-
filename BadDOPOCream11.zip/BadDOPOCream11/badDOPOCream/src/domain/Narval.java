package domain;

import javax.swing.ImageIcon;

public class Narval extends Enemy {

    public enum State {
        IDLE, CHARGING
    }

    public enum Direction {
        UP, DOWN, LEFT, RIGHT
    }

    private ImageIcon sprite;
    private State state;
    private Direction direction;

    public Narval(Position initialPosition) {
        super(initialPosition);
        this.sprite = new ImageIcon("resources/narval.jpg"); 
        this.state = State.IDLE;
        this.direction = Direction.RIGHT;
    }

    public ImageIcon getSprite() {
        return sprite;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public void move(Map map, Position iceCreamPos) {
        int x = position.getX();
        int y = position.getY();

        if (state == State.IDLE) {
            int iceX = iceCreamPos.getX();
            int iceY = iceCreamPos.getY();
            //embestidas 
            if (iceX == x) {
                state = State.CHARGING;
                direction = (iceY < y) ? Direction.UP : Direction.DOWN;
            } else if (iceY == y) {
                state = State.CHARGING;
                direction = (iceX < x) ? Direction.LEFT : Direction.RIGHT;
            } else {
                patrol(map);
                return;
            }
        }

        if (state == State.CHARGING) {
            int newX = x;
            int newY = y;

            switch (direction) {
                case UP:
                    newY--;
                    break;
                case DOWN:
                    newY++;
                    break;
                case LEFT:
                    newX--;
                    break;
                case RIGHT:
                    newX++;
                    break;
            }

            if (newX < 0 || newY < 0 || newX >= map.getCols() || newY >= map.getRows()) {
                state = State.IDLE;
                return;
            }

            Position next = new Position(newX, newY);

            if (map.isBlocked(next)) {
                map.clearCell(next); 
            }

            position.setX(newX);
            position.setY(newY);
        }
    }


    private void patrol(Map map) {
        int x = position.getX();
        int y = position.getY();
        int newX = x;

        if (direction == Direction.RIGHT) {
            newX++;
        } else if (direction == Direction.LEFT) {
            newX--;
        }

        Position next = new Position(newX, y);
        if (newX < 0 || newX >= map.getCols() || map.isBlocked(next)) {
            direction = (direction == Direction.RIGHT) ? Direction.LEFT : Direction.RIGHT;
        } else {
            position.setX(newX);
        }
    }
}
